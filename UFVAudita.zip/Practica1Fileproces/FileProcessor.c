#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <dirent.h>
#include <time.h>

#define MAX_PATH 1024

sem_t sems[5]; // Asumiendo un máximo de 5 procesos

char dir_comun[MAX_PATH];
char ruta_consolidado[MAX_PATH];
int valor_sleep;
char ruta_log[MAX_PATH];


void* escribir_archivos_y_mover(void* arg) {
    int num_proceso = *((int*) arg);

    // Aquí va el código para leer el archivo original y escribir su contenido en el archivo consolidado
    char buffer[1024];
    char original_filename[50];
    char prefix[10];
    sprintf(prefix, "SU00%d", num_proceso);

    DIR* dir = opendir(dir_comun);
    struct dirent* entry;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG && strncmp(entry->d_name, prefix, 5) == 0) {
            sprintf(original_filename, "%s/%s", dir_comun, entry->d_name);
            FILE* original_file = fopen(original_filename, "r");

            if (original_file == NULL) {
                printf("No se pudo abrir el archivo original: %s\n", original_filename);
                return NULL;
            }

            char consolidated_filename[50];
            sprintf(consolidated_filename, "%s", ruta_consolidado);
            FILE* consolidated_file = fopen(consolidated_filename, "a");

            if (consolidated_file == NULL) {
                printf("No se pudo abrir el archivo consolidado: %s\n", consolidated_filename);
                return NULL;
            }

            // Obtén la hora de inicio
            time_t inicio = time(NULL);
            int operaciones = 0;

            while (fgets(buffer, sizeof(buffer), original_file)) {
                fputs(buffer, consolidated_file);
                operaciones++;
            }

            fclose(original_file);
            fclose(consolidated_file);

            // Obtén la hora de fin
            time_t fin = time(NULL);

            // Escribe en el archivo de registro
            FILE* log_file = fopen(ruta_log, "a");
            if (log_file != NULL) {
		fprintf(log_file, "Se ha procesado un archivo:\n");
                fprintf(log_file, "%s:::%s:::%d:::%ld:::%ld:::%s:::%d\n",
                        __DATE__, __TIME__, num_proceso, inicio, fin, entry->d_name, operaciones);
                fclose(log_file);
            }

            // Ahora mueve el archivo a la carpeta 'leido'
            char command[50];
            sprintf(command, "mv ./comun/%s ./leido/", entry->d_name);
            system(command);
        }
    }

    closedir(dir);

    sem_post(&sems[num_proceso - 1]);
    return NULL;
}

int main() {
    FILE* fp = fopen("fp.conf", "r");
    char line[MAX_PATH];
    int num_procesos;

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "NUM_PROCESOS=", 13) == 0) {
            num_procesos = atoi(line + 13);
        } else if (strncmp(line, "PATH_FILE=", 10) == 0) {
            strcpy(dir_comun, line + 10);
            dir_comun[strcspn(dir_comun, "\n")] = 0; // Eliminar el salto de línea al final
        } else if (strncmp(line, "INVENTORY_FILE=", 15) == 0) {
            strcpy(ruta_consolidado, line + 15);
            ruta_consolidado[strcspn(ruta_consolidado, "\n")] = 0; // Eliminar el salto de línea al final
        }else if (strncmp(line, "SIMULATE_SLEEP=", 14) == 0) {
        valor_sleep = atoi(line + 14);
        }else if (strncmp(line, "LOG_FILE=", 9) == 0) {
            strcpy(ruta_log, line + 9);
            ruta_log[strcspn(ruta_log, "\n")] = 0; // Eliminar el salto de línea al final
        }

    }

    fclose(fp);

    pthread_t threads[num_procesos];
    int proceso_nums[num_procesos];

    char filename[50];
    sprintf(filename, "%s", ruta_consolidado);
    FILE* file = fopen(filename, "w");
    fclose(file);

    while(1) {
        DIR* dir = opendir(dir_comun);
        struct dirent* entry;

        while ((entry = readdir(dir)) != NULL) {
            if (entry->d_type == DT_REG) {
                for(int i = 0; i < num_procesos; i++) {
                    char filename[10];
                    sprintf(filename, "SU00%d", i + 1);

                    if (strncmp(entry->d_name, filename, 5) == 0) {
                        proceso_nums[i] = i + 1;
                        pthread_create(&threads[i], NULL, escribir_archivos_y_mover, &proceso_nums[i]);
                        pthread_join(threads[i], NULL);
                        break;
                    }
                }
            }
        }

        closedir(dir);
        sleep(valor_sleep); // Espera un valor (fp.conf) antes de comprobar de nuevo
    }

    for(int i = 0; i < num_procesos; i++) {
        sem_destroy(&sems[i]);
    }

    return 0;
}
