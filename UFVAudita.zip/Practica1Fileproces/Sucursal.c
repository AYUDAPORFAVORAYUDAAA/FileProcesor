#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Error: Debes proporcionar el número de sucursal como parámetro.\n");
        return 1;
    }
    int file_num = 1;
    int sucursal_num = atoi(argv[1]);
    char filename[50];
    srand(time(0)); // para generar números aleatorios

    // Crear la carpeta "comun" si no existe
    system("mkdir -p comun");

    while(1) {
        // Obtener la fecha actual
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        int day = tm.tm_mday;
        int month = tm.tm_mon + 1; // Los meses en C empiezan desde 0
        int year = tm.tm_year + 1900; // Los años en C empiezan desde 1900
        int hour = tm.tm_hour;
        int min = tm.tm_min;
        // Generar el nombre del archivo
        sprintf(filename, "comun/SU%03d_OPE00%d_%02d%02d%d_%d.data", sucursal_num, sucursal_num, day, month, year, file_num);

        // Abrir el archivo para escritura
        FILE *file = fopen(filename, "w");
        if(file == NULL) {
            printf("Error al abrir el archivo %s\n", filename);
            return 1;
        }

        // Escribir el contenido del archivo
        fprintf(file, "OPE%d;%02d/%02d/%d %02d:%02d;", sucursal_num, day, month, year, hour, min);
        hour = (hour + (rand() % 25)) % 24; // Añadir un número aleatorio de horas a la hora actual
        int user_id = (sucursal_num - 1) * 10 + (rand() % 10) + 1; // Generar un ID de usuario basado en el número de sucursal
        // Generar un número aleatorio entre 1 y 4 para representar las operaciones
        int operacion_num = rand() % 4 + 1;

        // Asignar una cadena de texto correspondiente a la operación
        const char* operacion;
        switch (operacion_num) {
                case 1:
                        operacion = "COMPRA";
                break;
                case 2:
                        operacion = "RETIRADA";
                break;
                case 3:
                        operacion = "TRANSFERENCIA";
                break;
                case 4:
                        operacion = "BIZUM";
                break;
        }


	fprintf(file, "%02d/%02d/%d %02d:%02d;USER%d;%s;%d;", day, month, year, hour, min, user_id, operacion, sucursal_num);


        switch(rand() % 3) {
            case 0:
                fprintf(file, "Error");
                break;
            case 1:
                fprintf(file, "Finalizado");
                break;
            case 2:
                fprintf(file, "Correcto");
                break;
        }
        fprintf(file, "\n");

        // Cerrar el archivo
        fclose(file);

        printf("Archivo %s creado.\n", filename);

        //Ahora incrementa el numero de archivo
        file_num++;
        // Esperar 10 segundos antes de crear el próximo archivo
        sleep(1);
    }

    return 0;
}
