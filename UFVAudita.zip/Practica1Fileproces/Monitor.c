#define _XOPEN_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <string.h>


#define NUM_THREADS 4

sem_t sem;

#define MAX_PATH 1024
char ruta_consolidado[MAX_PATH];
char ruta_log[MAX_PATH];


int moni=0;
#include <time.h>
#include <string.h>

#define MAX_LINE_LENGTH 1024
#define MAX_USER_LENGTH 64

// Estructura para almacenar los ID de usuario y su conteo
typedef struct UserNode {
    char id[MAX_USER_LENGTH];
    int count;
    struct UserNode *next;
} UserNode;

void *threadFunc1(void *arg) {
    sem_wait(&sem);  // Espera hasta que el semáforo esté disponible

    FILE *file = fopen(ruta_consolidado, "r");
    if (file == NULL) {
        printf("No se pudo abrir el archivo consolidado.csv (Func1)\n");
        return NULL;
    }

    char line[MAX_LINE_LENGTH];
    char user[MAX_USER_LENGTH];
    char time_str[MAX_USER_LENGTH];
    char status[MAX_USER_LENGTH];
    struct tm tm;
    UserNode *head = NULL;

    // Leer el archivo y contar las apariciones de cada usuario
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

        // Elimina el carácter de nueva línea de status
        status[strcspn(status, "\n")] = 0;

        // Comprobar si el usuario ya está en la lista
        UserNode *current = head;
        while (current != NULL && strcmp(current->id, user) != 0) {
            current = current->next;
        }

        // Si el usuario está en la lista, incrementa su conteo
        if (current != NULL) {
            current->count++;
        } else {
            // Si el usuario no está en la lista, añadirlo
            UserNode *new_node = malloc(sizeof(UserNode));
            strcpy(new_node->id, user);
            new_node->count = 1;
            new_node->next = head;
            head = new_node;
        }
    }

    // Verificar cada usuario para el patrón 1
    UserNode *current = head;
    while (current != NULL) {
        // Si un usuario ha hecho más de 5 transacciones
        if (current->count > 5) {
// Redirige stdout al archivo log.log
FILE *log_fp = fopen(ruta_log, "a");
    if (log_fp == NULL) {
        printf("No se pudo abrir el archivo de registro.\n");
        return 1;
    }

    // Ahora, puedes usar fprintf para escribir en ambos, la pantalla y el archivo.
printf("El patrón 1 ha sido detectado en el usuario %s y ha hecho %d transacciones.\n", current->id, current->count);
fprintf(log_fp,"El patrón 1 ha sido detectado en el usuario %s y ha hecho %d transacciones.\n", current->id, current->count);

    // Cierra el archivo de registro.
    fclose(log_fp);

moni++;
}

        current = current->next;
    }

    // Liberar la memoria de la lista
    while (head != NULL) {
        UserNode *next = head->next;
        free(head);
        head = next;
    }

    fclose(file);

    sem_post(&sem);  // Libera el semáforo
    return NULL;
}

void *threadFunc2(void *arg) {
    sem_wait(&sem);  // Espera hasta que el semáforo esté disponible

    FILE *file = fopen(ruta_consolidado, "r");
    if (file == NULL) {
        printf("No se pudo abrir el archivo consolidado.csv (Func2)\n");
        return NULL;
    }

    char line[MAX_LINE_LENGTH];
    char user[MAX_USER_LENGTH];
    char time_str[MAX_USER_LENGTH];
    char operation[MAX_USER_LENGTH];
    char status[MAX_USER_LENGTH];
    struct tm tm;
    UserNode *head = NULL;

    // Leer el archivo y almacenar los ID de usuario únicos
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%[^;]", time_str, user, operation, status);

        // Elimina el carácter de nueva línea de status
        status[strcspn(status, "\n")] = 0;

        // Comprobar si el usuario ya está en la lista
        UserNode *current = head;
        while (current != NULL && strcmp(current->id, user) != 0) {
            current = current->next;
        }

        // Si el usuario no está en la lista, añadirlo
        if (current == NULL) {
            UserNode *new_node = malloc(sizeof(UserNode));
            strcpy(new_node->id, user);
            new_node->next = head;
            head = new_node;
        }
    }

    // Verificar cada usuario para el patrón 2
    UserNode *current = head;
    while (current != NULL) {
        fseek(file, 0, SEEK_SET);  // Volver al principio del archivo
        int withdrawals = 0;
        char current_day[11] = "";

        while (fgets(line, sizeof(line), file)) {
            sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%[^;]", time_str, user, operation, status);

            // Elimina el carácter de nueva línea de status
            status[strcspn(status, "\n")] = 0;

            // Si es el mismo usuario y la operación es una retirada en el mismo día
            if (strcmp(user, current->id) == 0 && strncmp(time_str, current_day, 10) == 0 && strcmp(operation, "RETIRADA") == 0) {
                withdrawals++;
            } else if (strcmp(user, current->id) == 0 && strncmp(time_str, current_day, 10) != 0) {
                // Si es el mismo usuario pero en un día diferente, reinicia el contador de retiradas
                strncpy(current_day, time_str, 10);
                withdrawals = (strcmp(operation, "RETIRADA") == 0) ? 1 : 0;
            }

            // Si un usuario ha hecho más de 3 retiradas en un mismo día
            if (withdrawals > 3) {
// Redirige stdout al archivo log.log
FILE *log_fp = fopen(ruta_log, "a"); 
    if (log_fp == NULL) {
        printf("No se pudo abrir el archivo de registro.\n");
        return 1;
    }

    // Ahora, puedes usar fprintf para escribir en ambos, la pantalla y el archivo.
printf("El patrón 2 ha sido detectado, el usuario %s en el día %s más de 3 retiradas.\n", current->id, current_day);
fprintf(log_fp,"El patrón 2 ha sido detectado, el usuario %s en el día %s más de 3 retiradas.\n", current->id, current_day);

    // Cierra el archivo de registro.
    fclose(log_fp);


moni++;
break; 
            }
        }

        current = current->next;
    }

    // Liberar la memoria de la lista
    while (head != NULL) {
        UserNode *next = head->next;
        free(head);
        head = next;
    }

    fclose(file);

    sem_post(&sem);  // Libera el semáforo
    return NULL;
}



void *threadFunc3(void *arg) {
    sem_wait(&sem);  // Espera hasta que el semáforo esté disponible

    FILE *file = fopen(ruta_consolidado, "r");
    if (file == NULL) {
        printf("No se pudo abrir el archivo consolidado.csv (Func3)\n");
        return NULL;
    }

    char line[MAX_LINE_LENGTH];
    char user[MAX_USER_LENGTH];
    char time_str[MAX_USER_LENGTH];
    char status[MAX_USER_LENGTH];
    struct tm tm;
    UserNode *head = NULL;
	UserNode *current = NULL;

    // Leer el archivo y almacenar los ID de usuario únicos
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

        // Elimina el carácter de nueva línea de status
        status[strcspn(status, "\n")] = 0;

        // Comprobar si el usuario ya está en la lista
        UserNode *current = head;
        while (current != NULL && strcmp(current->id, user) != 0) {
            current = current->next;
        }

        // Si el usuario no está en la lista, añadirlo
        if (current == NULL) {
            UserNode *new_node = malloc(sizeof(UserNode));
            strcpy(new_node->id, user);
            new_node->next = head;
            head = new_node;
        }
    }

    // Verificar cada usuario para las transacciones de error
    current = head;
    while (current != NULL) {
        fseek(file, 0, SEEK_SET);  // Volver al principio del archivo
        int errors = 0;

        while (fgets(line, sizeof(line), file)) {
            sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%*[^;];%*[^;];%[^;]", time_str, user, status);

            // Elimina el carácter de nueva línea de status
            status[strcspn(status, "\n")] = 0;

            // Si es el mismo usuario y la transacción es un error
            if (strcmp(user, current->id) == 0 && strcmp(status, "Error") == 0) {
                errors++;
            }
        }

        // Si un usuario ha hecho más de 3 transacciones de error en un día
        if (errors > 3) {
// Redirige stdout al archivo log.log
FILE *log_fp = fopen(ruta_log, "a");
    if (log_fp == NULL) {
        printf("No se pudo abrir el archivo de registro.\n");
        return 1;
    }

    // Ahora, puedes usar fprintf para escribir en ambos, la pantalla y el archivo.
printf("El patrón 3 ha sido detectado en el usuario %s y tiene %d avisos de error.\n", current->id, errors);
fprintf(log_fp,"El patrón 3 ha sido detectado en el usuario %s y tiene %d avisos de error.\n", current->id, errors);


    // Cierra el archivo de registro.
    fclose(log_fp);
       moni++;
 }

        current = current->next;
    }

    // Liberar la memoria de la lista
    while (head != NULL) {
        UserNode *next = head->next;
        free(head);
        head = next;
    }

    fclose(file);

    sem_post(&sem);  // Libera el semáforo
    return NULL;
}


void *threadFunc4(void *arg) {
    sem_wait(&sem);  // Espera hasta que el semáforo esté disponible

    FILE *file = fopen(ruta_consolidado, "r");
    if (file == NULL) {
        printf("No se pudo abrir el archivo consolidado.csv (Func4)\n");
        return NULL;
    }

    char line[MAX_LINE_LENGTH];
    char user[MAX_USER_LENGTH];
    char time_str[MAX_USER_LENGTH];
    char operation[MAX_USER_LENGTH];
    struct tm tm;
    UserNode *head = NULL;
    UserNode *current = NULL;  // Añade esta línea

    // Leer el archivo y almacenar los ID de usuario únicos
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%*[^;]", time_str, user, operation);

        // Elimina el carácter de nueva línea de operation
        operation[strcspn(operation, "\n")] = 0;

        // Comprobar si el usuario ya está en la lista
        UserNode *current = head;
        while (current != NULL && strcmp(current->id, user) != 0) {
            current = current->next;
        }

        // Si el usuario no está en la lista, añadirlo
        if (current == NULL) {
            UserNode *new_node = malloc(sizeof(UserNode));
            strcpy(new_node->id, user);
            new_node->next = head;
            head = new_node;
        }
    }

    // Verificar cada usuario para los diferentes tipos de operación en un mismo día
    current = head;
    while (current != NULL) {
        fseek(file, 0, SEEK_SET);  // Volver al principio del archivo
        int retirada = 0, bizum = 0, transaccion = 0, compra = 0;
        char current_day[11] = "";

        while (fgets(line, sizeof(line), file)) {
            sscanf(line, "%*[^;];%[^;];%*[^;];%[^;];%[^;];%*[^;];%*[^;]", time_str, user, operation);

            // Elimina el carácter de nueva línea de operation
            operation[strcspn(operation, "\n")] = 0;

            // Si es el mismo usuario y la operación ocurrió en el mismo día
            if (strcmp(user, current->id) == 0 && strncmp(time_str, current_day, 10) == 0) {
                if (strcmp(operation, "RETIRADA") == 0) {
                    retirada = 1;
                } else if (strcmp(operation, "BIZUM") == 0) {
                    bizum = 1;
                } else if (strcmp(operation, "TRANSFERENCIA") == 0) {
                    transaccion = 1;
                } else if (strcmp(operation, "COMPRA") == 0) {
                    compra = 1;
                }
            } else if (strcmp(user, current->id) == 0) {
                // Si es el mismo usuario pero en un día diferente, reinicia los contadores de operación
                strncpy(current_day, time_str, 10);
                retirada = (strcmp(operation, "RETIRADA") == 0) ? 1 : 0;
                bizum = (strcmp(operation, "BIZUM") == 0) ? 1 : 0;
                transaccion = (strcmp(operation, "TRANSFERENCIA") == 0) ? 1 : 0;
                compra = (strcmp(operation, "COMPRA") == 0) ? 1 : 0;
            }

            // Si un usuario ha hecho al menos una operación de cada tipo en un mismo día
            if (retirada && bizum && transaccion && compra) {
// Redirige stdout al archivo log.log
FILE *log_fp = fopen(ruta_log, "a");
    if (log_fp == NULL) {
        printf("No se pudo abrir el archivo de registro.\n");
        return 1;
    }

    // Ahora, puedes usar fprintf para escribir en ambos, la pantalla y el archivo.
printf("El patrón 4 ha sido detectado en el usuario %s en el día %s.\n", current->id, current_day);
fprintf(log_fp,"El patrón 4 ha sido detectado en el usuario %s en el día %s.\n", current->id, current_day);


    // Cierra el archivo de registro.
    fclose(log_fp);

moni++;
break; 
            }
        }

        current = current->next;
    }

    // Liberar la memoria de la lista
    while (head != NULL) {
        UserNode *next = head->next;
        free(head);
        head = next;
    }

    fclose(file);

    sem_post(&sem);  // Libera el semáforo
    return NULL;
}


int main() {
	char line[MAX_PATH];
    FILE* fp = fopen("fp.conf", "r");
    char lines[MAX_PATH];

    while (fgets(lines, sizeof(lines), fp)) {
        if (strncmp(lines, "INVENTORY_FILE=", 15) == 0) {
            strcpy(ruta_consolidado, lines + 15);
            ruta_consolidado[strcspn(ruta_consolidado, "\n")] = 0; // Eliminar el salto de línea al final
        }else if (strncmp(lines, "LOG_FILE=", 9) == 0) {
            strcpy(ruta_log, lines + 9);
            ruta_log[strcspn(ruta_log, "\n")] = 0; // Eliminar el salto de línea al final
        }
    }
    fclose(fp);
    pthread_t threads[NUM_THREADS];
    sem_init(&sem, 0, 1);  // Inicializa el semáforo

    // Crea los hilos
    pthread_create(&threads[0], NULL, threadFunc1, NULL);
    pthread_create(&threads[1], NULL, threadFunc2, NULL);
    pthread_create(&threads[2], NULL, threadFunc3, NULL);
    pthread_create(&threads[3], NULL, threadFunc4, NULL);

    // Espera a que todos los hilos terminen
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
	if(moni == 0){
printf("No se han detectado patrones.");
}
else{
printf("Los patrones detectados se han guardado en el archivo %s",ruta_log);
}
    sem_destroy(&sem);  // Destruye el semáforo
    return 0;
}

