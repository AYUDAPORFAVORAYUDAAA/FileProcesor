#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void* ejecutar_sucursal(void* arg) {
    int num_sucursal = *((int*) arg);
    char command[50];
    sprintf(command, "./Sucursal %d", num_sucursal);
    system(command);
    return NULL;
}

int main() {
    FILE* fp = fopen("fp.conf", "r");
    char line[1024];
    int num_sucursales;

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "NUM_PROCESOS=", 13) == 0) {
            num_sucursales = atoi(line + 13);
            break;
        }
    }

    fclose(fp);

    pthread_t threads[num_sucursales];
    int sucursal_nums[num_sucursales];

    for(int i = 0; i < num_sucursales; i++) {
        sucursal_nums[i] = i + 1;
        pthread_create(&threads[i], NULL, ejecutar_sucursal, &sucursal_nums[i]);
    }

    for(int i = 0; i < num_sucursales; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}

